import React from "react";

const Finished = (props) => {
    return (
        <div className="login-container">
            <h1 className="welcome-message">Voting Completed</h1>
        </div>
    )
}

export default Finished;